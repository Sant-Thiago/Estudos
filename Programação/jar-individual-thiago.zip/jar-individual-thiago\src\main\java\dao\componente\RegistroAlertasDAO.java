package dao.componente;

public class RegistroAlertasDAO {

}
