package dao.alerta;

public class alertaDAO {
}
